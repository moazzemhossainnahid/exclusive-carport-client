export const CompleteCollectionData = [
    {
        id: 1,
        title: "Carport",
        href: "carport",
        img: "https://i.ibb.co/10hSgpn/image-3.png",
    },
    {
        id: 2,
        title: "Massage Chair",
        href: "massagechair",
        img: "https://i.ibb.co/bgbsj69/DSC03614-3.png",
    },
    {
        id: 3,
        title: "Furniture",
        href: "furniture",
        img: "https://i.ibb.co/2Ybnw7x/sofa-1.png",
    },
    {
        id: 4,
        title: "Lights",
        href: "lights",
        img: "https://i.ibb.co/7GbC1ZQ/image-4.png",
    },
]