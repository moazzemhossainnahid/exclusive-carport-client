export const SuperSellPData = [
    {
        id: 1,
        title: "Interior Design Sofa Set",
        tag: "Exclusive",
        img: "https://i.ibb.co/HXYYkkF/Rectangle-131.png",
        price: 125
    },
    {
        id: 2,
        title: "Interior Design Sofa Set",
        tag: "Exclusive",
        img: "https://i.ibb.co/HXYYkkF/Rectangle-131.png",
        price: 125
    },
    {
        id: 3,
        title: "Interior Design Sofa Set",
        tag: "Exclusive",
        img: "https://i.ibb.co/HXYYkkF/Rectangle-131.png",
        price: 125
    },
    {
        id: 4,
        title: "Interior Design Sofa Set",
        tag: "Exclusive",
        img: "https://i.ibb.co/HXYYkkF/Rectangle-131.png",
        price: 125
    },
    {
        id: 5,
        title: "Interior Design Sofa Set",
        tag: "Exclusive",
        img: "https://i.ibb.co/HXYYkkF/Rectangle-131.png",
        price: 125
    },
    {
        id: 6,
        title: "Interior Design Sofa Set",
        tag: "Exclusive",
        img: "https://i.ibb.co/HXYYkkF/Rectangle-131.png",
        price: 125
    },
]