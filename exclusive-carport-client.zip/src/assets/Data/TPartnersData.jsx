export const TPartnersData = [
    {
        imageURL: 'https://i.ibb.co/3Bh0V4M/Group-95.png',
        alt:"1"
    },
    {
        imageURL: 'https://i.ibb.co/23dQnCJ/Group-96.png',
        alt:"2"
    },
    {
        imageURL: 'https://i.ibb.co/BLhMhm9/Group-97.png',
        alt:"3"
    },
    {
        imageURL: 'https://i.ibb.co/K09HDcH/Group-98.png',
        alt:"4"
    },
    {
        imageURL: 'https://i.ibb.co/BGCpsZV/Group-99.png',
        alt:"5"
    },
    {
        imageURL: 'https://i.ibb.co/XxQDNvH/Group-100.png',
        alt:"6"
    },

];







