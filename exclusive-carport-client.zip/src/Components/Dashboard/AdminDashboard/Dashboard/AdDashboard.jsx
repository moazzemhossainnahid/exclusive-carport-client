
import DBCards from './DBCards/DBCards';

const AdDashboard = () => {
    return (
        <div className=''>
            <DBCards/>
        </div>
    ); 
};
 
export default AdDashboard;