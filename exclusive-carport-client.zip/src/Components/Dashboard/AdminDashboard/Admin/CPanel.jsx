
import Sidebar from './Sidebar/Sidebar';

const CPanel = () => {
    return (
        <div className='bg-white pt-20'>
            <Sidebar/>
        </div>
    );
}; 

export default CPanel;