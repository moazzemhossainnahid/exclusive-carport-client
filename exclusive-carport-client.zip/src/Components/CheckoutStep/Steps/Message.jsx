import React from 'react';
import './strpStyle.css';
const Message = ({message}) => {
    return (
        <section>
        <p>{message}</p>
      </section>
    );
};

export default Message;